#include <Tulpar/Core/Logger.h>
#include <iostream>

namespace tulpar {
void log(LogLevel level, std::string_view message) {
    const char* prefix = level == LogLevel::Info ? "[INFO] " :
                         level == LogLevel::Warning ? "[WARN] " : "[ERROR] ";
    std::cout << prefix << message << '\n';
}
}
