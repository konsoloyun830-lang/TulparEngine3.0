#include <Tulpar/Scene/Node.h>
#include <atomic>
#include <utility>

namespace tulpar {
namespace { std::atomic<ObjectId> next_id{1}; }

Node::Node(std::string name)
    : id_(next_id.fetch_add(1, std::memory_order_relaxed)),
      name_(std::move(name)) {}

Node& Node::add_child(std::unique_ptr<Node> child) {
    children_.push_back(std::move(child));
    return *children_.back();
}
}
