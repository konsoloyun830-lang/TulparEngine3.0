#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <memory>

namespace tulpar {
using ObjectId = std::uint64_t;

class Node {
public:
    explicit Node(std::string name = "Node");
    virtual ~Node() = default;
    Node(const Node&) = delete;
    Node& operator=(const Node&) = delete;

    ObjectId id() const noexcept { return id_; }
    const std::string& name() const noexcept { return name_; }
    void set_name(std::string name) { name_ = std::move(name); }

    Node& add_child(std::unique_ptr<Node> child);
    const std::vector<std::unique_ptr<Node>>& children() const noexcept {
        return children_;
    }

private:
    ObjectId id_;
    std::string name_;
    std::vector<std::unique_ptr<Node>> children_;
};
}
