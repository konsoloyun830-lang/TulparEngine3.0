add_library(TulparCore STATIC
    Core/Source/Logger.cpp
    Scene/Source/Node.cpp)
target_include_directories(TulparCore PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/Core/Include
    ${CMAKE_CURRENT_SOURCE_DIR}/Scene/Include)
target_compile_features(TulparCore PUBLIC cxx_std_20)
