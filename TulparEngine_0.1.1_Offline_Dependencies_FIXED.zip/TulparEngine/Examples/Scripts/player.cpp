// Hedef native script API örneği; mevcut prototipte henüz derlenmez.
#include <Tulpar/Scene/CharacterBody3D.h>
#include <Tulpar/Platform/Input.h>

class Player : public tulpar::CharacterBody3D {
public:
    float speed = 6.0f;

    void physics_process(float delta) override {
        auto v = velocity();
        v.x = tulpar::Input::get_axis("move_left", "move_right") * speed;
        set_velocity(v);
        move_and_slide();
    }
};
