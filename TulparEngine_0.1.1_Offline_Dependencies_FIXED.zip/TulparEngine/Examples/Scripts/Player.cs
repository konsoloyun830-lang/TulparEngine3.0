// Hedef C# API örneği; .NET binding henüz uygulanmamıştır.
using Tulpar;

public sealed class Player : CharacterBody3D
{
    public float Speed { get; set; } = 6.0f;

    public override void PhysicsProcess(float delta)
    {
        float axis = Input.GetAxis("move_left", "move_right");
        Velocity = new Vector3(axis * Speed, Velocity.Y, Velocity.Z);
        MoveAndSlide();
    }
}
