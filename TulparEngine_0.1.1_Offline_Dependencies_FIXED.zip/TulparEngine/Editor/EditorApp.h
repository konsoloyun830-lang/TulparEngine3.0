#pragma once
namespace tulpar {
class EditorApp {
public:
    int run();
};
}
