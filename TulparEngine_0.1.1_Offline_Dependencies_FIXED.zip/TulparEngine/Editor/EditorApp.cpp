#include "EditorApp.h"
#include <Tulpar/Core/Logger.h>
#include <GLFW/glfw3.h>
#include <GL/gl.h>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <algorithm>
#include <string>

namespace tulpar {
namespace {
struct EditorState {
    bool project_open = false;
    bool show_demo = false;
    int selected_object = 0;
    float camera_speed = 4.0f;
    std::string project_name = "My First Tulpar Game";
};

void apply_theme() {
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 7.0f;
    s.ChildRounding = 6.0f;
    s.FrameRounding = 5.0f;
    s.PopupRounding = 6.0f;
    s.ScrollbarRounding = 8.0f;
    s.GrabRounding = 5.0f;
    s.WindowPadding = ImVec2(10, 10);
    s.FramePadding = ImVec2(8, 5);
    s.ItemSpacing = ImVec2(8, 7);
    s.Colors[ImGuiCol_WindowBg]       = ImVec4(0.075f,0.083f,0.102f,1);
    s.Colors[ImGuiCol_ChildBg]        = ImVec4(0.090f,0.101f,0.124f,1);
    s.Colors[ImGuiCol_TitleBg]        = ImVec4(0.060f,0.068f,0.085f,1);
    s.Colors[ImGuiCol_TitleBgActive]  = ImVec4(0.095f,0.115f,0.150f,1);
    s.Colors[ImGuiCol_Header]         = ImVec4(0.16f,0.29f,0.43f,0.75f);
    s.Colors[ImGuiCol_HeaderHovered]  = ImVec4(0.19f,0.39f,0.58f,0.85f);
    s.Colors[ImGuiCol_Button]         = ImVec4(0.13f,0.29f,0.44f,1);
    s.Colors[ImGuiCol_ButtonHovered]  = ImVec4(0.18f,0.40f,0.59f,1);
    s.Colors[ImGuiCol_CheckMark]      = ImVec4(0.24f,0.68f,0.95f,1);
    s.Colors[ImGuiCol_SliderGrab]     = ImVec4(0.20f,0.58f,0.86f,1);
    s.Colors[ImGuiCol_Tab]            = ImVec4(0.10f,0.15f,0.21f,1);
    s.Colors[ImGuiCol_TabSelected]      = ImVec4(0.14f,0.29f,0.43f,1);
}
void toolbar() {
    ImGui::Begin("Toolbar");
    ImGui::TextColored(ImVec4(0.28f,0.72f,1.0f,1), "TULPAR");
    ImGui::SameLine(105);
    ImGui::Button("Select"); ImGui::SameLine();
    ImGui::Button("Move"); ImGui::SameLine();
    ImGui::Button("Rotate"); ImGui::SameLine();
    ImGui::Button("Scale"); ImGui::SameLine();
    ImGui::Spacing(); ImGui::SameLine();
    ImGui::Button("Play"); ImGui::SameLine();
    ImGui::Button("Pause"); ImGui::SameLine();
    ImGui::Button("Stop");
    ImGui::End();
}
void project_manager(EditorState& state) {
    ImGui::SetNextWindowSize(ImVec2(760, 470), ImGuiCond_FirstUseEver);
    ImGui::Begin("Tulpar Project Manager");
    ImGui::TextColored(ImVec4(0.30f,0.72f,1.0f,1), "TULPAR ENGINE");
    ImGui::SameLine();
    ImGui::TextDisabled("0.1.0  |  Project Hub");
    ImGui::Separator();
    ImGui::Spacing();
    ImGui::Text("Welcome back");
    ImGui::TextDisabled("Create a project or open an existing workspace.");
    ImGui::Spacing();
    ImGui::BeginChild("CreateCard", ImVec2(0,105), true);
    ImGui::Text("NEW PROJECT");
    ImGui::TextDisabled("Start with a clean 3D project.");
    ImGui::SetNextItemWidth(300);
    char name[128] = {};
    std::copy_n(state.project_name.c_str(),
                std::min(state.project_name.size(), sizeof(name)-1), name);
    if (ImGui::InputText("Project name", name, sizeof(name)))
        state.project_name = name;
    ImGui::SameLine();
    if (ImGui::Button("Create 3D Project", ImVec2(160, 30)))
        state.project_open = true;
    ImGui::EndChild();
    ImGui::Spacing();
    ImGui::Text("RECENT PROJECTS");
    ImGui::BeginChild("RecentProjects", ImVec2(0, 115), true);
    if (ImGui::Selectable("  [3D]  My First Tulpar Game", state.project_open))
        state.project_open = true;
    ImGui::TextDisabled("  No project files are written in this preview build.");
    ImGui::EndChild();
    ImGui::Spacing();
    if (ImGui::Button("Open Editor", ImVec2(140, 32)))
        state.project_open = true;
    ImGui::End();
}
void scene_panel() {
    ImGui::Begin("Scene Hierarchy");
    if (ImGui::TreeNodeEx("World", ImGuiTreeNodeFlags_DefaultOpen |
                          ImGuiTreeNodeFlags_OpenOnArrow)) {
        ImGui::TreeNodeEx("Camera3D", ImGuiTreeNodeFlags_Leaf);
        ImGui::TreePop();
        if (ImGui::TreeNodeEx("DirectionalLight3D", ImGuiTreeNodeFlags_Leaf))
            ImGui::TreePop();
        if (ImGui::TreeNodeEx("Ground", ImGuiTreeNodeFlags_Leaf))
            ImGui::TreePop();
    }
    ImGui::End();
}
void inspector_panel(EditorState& state) {
    ImGui::Begin("Inspector");
    ImGui::TextDisabled("No object selected");
    ImGui::Separator();
    ImGui::Text("Transform");
    float p[3] = {0,0,0}, r[3] = {0,0,0}, sc[3] = {1,1,1};
    ImGui::DragFloat3("Position", p, 0.1f);
    ImGui::DragFloat3("Rotation", r, 0.5f);
    ImGui::DragFloat3("Scale", sc, 0.1f);
    ImGui::Separator();
    ImGui::Text("Editor");
    ImGui::SliderFloat("Camera speed", &state.camera_speed, 0.5f, 20.0f);
    ImGui::End();
}
void viewport() {
    ImGui::Begin("3D Viewport");
    ImGui::TextDisabled("Perspective  |  Grid preview");
    ImVec2 size = ImGui::GetContentRegionAvail();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 a = ImGui::GetCursorScreenPos();
    ImVec2 b(a.x + size.x, a.y + size.y);
    draw->AddRectFilled(a, b, IM_COL32(24,31,43,255));
    const float cx = (a.x+b.x)*0.5f, cy = (a.y+b.y)*0.57f;
    for (int i=-12; i<=12; ++i) {
        float offset = i * 22.0f;
        draw->AddLine(ImVec2(cx+offset, a.y+12), ImVec2(cx+offset*2.4f, b.y),
                      IM_COL32(57,72,91,130));
        draw->AddLine(ImVec2(a.x+8, cy+offset*0.42f), ImVec2(b.x-8, cy+offset*0.42f),
                      IM_COL32(57,72,91,130));
    }
    draw->AddLine(ImVec2(cx,cy), ImVec2(cx+115,cy), IM_COL32(220,75,75,255),2);
    draw->AddLine(ImVec2(cx,cy), ImVec2(cx,cy-95), IM_COL32(90,205,120,255),2);
    draw->AddCircleFilled(ImVec2(cx,cy),5,IM_COL32(80,170,245,255));
    ImGui::Dummy(size);
    ImGui::End();
}
void asset_panel() {
    ImGui::Begin("Content Browser");
    ImGui::TextDisabled("Content  /  Assets");
    ImGui::Separator();
    ImGui::Button("  [DIR] Scenes"); ImGui::SameLine();
    ImGui::Button("  [DIR] Scripts"); ImGui::SameLine();
    ImGui::Button("  [DIR] Materials"); ImGui::SameLine();
    ImGui::Button("  [DIR] Textures");
    ImGui::End();
}
}

int EditorApp::run() {
    if (!glfwInit()) {
        log(LogLevel::Error, "GLFW initialization failed.");
        return 1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
#endif
    GLFWwindow* window = glfwCreateWindow(1440, 900, "Tulpar Engine 0.1.0", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    apply_theme();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    EditorState state;
    log(LogLevel::Info, "Tulpar Editor started.");

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        ImGui::DockSpaceOverViewport(0, ImGui::GetMainViewport());
        if (state.project_open) {
            toolbar();
            scene_panel();
            viewport();
            inspector_panel(state);
            asset_panel();
        } else {
            project_manager(state);
        }
        if (state.show_demo) ImGui::ShowDemoWindow(&state.show_demo);

        ImGui::Render();
        int w,h; glfwGetFramebufferSize(window,&w,&h);
        glViewport(0,0,w,h);
        glClearColor(0.055f,0.063f,0.078f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}

} // namespace tulpar
