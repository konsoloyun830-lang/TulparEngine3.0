#include "EditorApp.h"
#include <exception>
#include <iostream>

int main() {
    try {
        tulpar::EditorApp app;
        return app.run();
    } catch (const std::exception& e) {
        std::cerr << "Tulpar Editor fatal error: " << e.what() << '\n';
        return 1;
    }
}
