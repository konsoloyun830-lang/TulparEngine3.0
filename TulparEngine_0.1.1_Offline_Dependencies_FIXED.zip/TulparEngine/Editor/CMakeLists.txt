add_executable(TulparEditor
    Main.cpp
    EditorApp.cpp)
target_include_directories(TulparEditor PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
    ${CMAKE_CURRENT_SOURCE_DIR}/../Engine/Core/Include
    ${CMAKE_CURRENT_SOURCE_DIR}/../Engine/Scene/Include)
find_package(OpenGL REQUIRED)
target_link_libraries(TulparEditor PRIVATE TulparCore glfw tulpar_imgui OpenGL::GL)

if(WIN32 AND MSVC)
    add_custom_command(TARGET TulparEditor POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
            "${CMAKE_CURRENT_SOURCE_DIR}/../ThirdParty/GLFW/lib-vc2022/glfw3.dll"
            "$<TARGET_FILE_DIR:TulparEditor>/glfw3.dll")
endif()
