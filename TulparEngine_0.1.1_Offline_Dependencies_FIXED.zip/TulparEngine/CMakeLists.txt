cmake_minimum_required(VERSION 3.25)
project(TulparEngine VERSION 0.1.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(TULPAR_BUILD_EDITOR "Build the native Tulpar Editor" ON)

if(TULPAR_BUILD_EDITOR)
    # GLFW 3.4 is bundled for Windows/MSVC so configuration does not need GitHub.
    if(WIN32 AND MSVC)
        set(TULPAR_GLFW_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/ThirdParty/GLFW")
        if(NOT EXISTS "${TULPAR_GLFW_ROOT}/lib-vc2022/glfw3.lib" OR
           NOT EXISTS "${TULPAR_GLFW_ROOT}/lib-vc2022/glfw3.dll")
            message(FATAL_ERROR "Bundled GLFW MSVC 2022 files are missing.")
        endif()
        add_library(glfw SHARED IMPORTED GLOBAL)
        set_target_properties(glfw PROPERTIES
            IMPORTED_IMPLIB "${TULPAR_GLFW_ROOT}/lib-vc2022/glfw3.lib"
            IMPORTED_LOCATION "${TULPAR_GLFW_ROOT}/lib-vc2022/glfw3.dll"
            INTERFACE_INCLUDE_DIRECTORIES "${TULPAR_GLFW_ROOT}/include")
    else()
        message(FATAL_ERROR
            "This offline bundle includes GLFW binaries for Windows/MSVC 2022. "
            "Build the editor with Visual Studio 2022 on Windows.")
    endif()

    # Dear ImGui docking branch is vendored in ThirdParty/ImGui.
    set(IMGUI_DIR "${CMAKE_CURRENT_SOURCE_DIR}/ThirdParty/ImGui")
    add_library(tulpar_imgui STATIC
        ${IMGUI_DIR}/imgui.cpp
        ${IMGUI_DIR}/imgui_draw.cpp
        ${IMGUI_DIR}/imgui_tables.cpp
        ${IMGUI_DIR}/imgui_widgets.cpp
        ${IMGUI_DIR}/backends/imgui_impl_glfw.cpp
        ${IMGUI_DIR}/backends/imgui_impl_opengl3.cpp)
    target_include_directories(tulpar_imgui PUBLIC
        ${IMGUI_DIR}
        ${IMGUI_DIR}/backends
        ${TULPAR_GLFW_ROOT}/include)
    target_link_libraries(tulpar_imgui PUBLIC glfw)

    add_subdirectory(Engine)
    add_subdirectory(Editor)
endif()
