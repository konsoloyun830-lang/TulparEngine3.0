# Yol Haritası

- 0.1.0: Native pencere, ImGui docking, Project Manager ve editör panel iskeleti.
- 0.2.0: Gerçek Scene Graph, Transform ve `.tulpar` JSON serileştirme.
- 0.3.0: RHI ve gerçek 3D mesh/camera/grid çizimi.
- 0.4.0: TPScript Lexer, Parser, AST ve VM.
- 0.5.0: Reflection Registry ve TPScript binding.
- 0.6.0: .NET host ve C# binding.
- 0.7.0: Jolt Physics entegrasyonu.
- 0.8.0: PBR, ışık ve gölge.
- 0.9.0: Asset Browser, importer, gizmo ve script editor.
- 1.0.0: Paketleme, oyun build sistemi ve platform testleri.
