# TPScript — Dil Taslağı

```python
extends CharacterBody3D

@export var speed: float = 6.0

func _ready() -> void:
    print("Tulpar Player Ready!")

func _physics_process(delta: float) -> void:
    var axis = Input.get_axis("move_left", "move_right")
    velocity.x = axis * speed
    move_and_slide()
```

İşleme hattı: Source → Lexer → Tokens → Parser → AST → Bytecode Compiler → VM → Engine Binding.

Önerilen ilk dil kapsamı: değişkenler, sayılar, string, bool, fonksiyonlar, if/else, while, return, çağrı, property erişimi, `extends`, `@export` ve temel Vector türleri.
