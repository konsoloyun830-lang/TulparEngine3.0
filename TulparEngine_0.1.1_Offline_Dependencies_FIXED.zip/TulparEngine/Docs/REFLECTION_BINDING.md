# Reflection ve Binding Sözleşmesi

C++ sınıfları tek kaynak kabul edilir. ClassDB, sınıf adı, özellikler, metotlar, sinyaller ve tür bilgisini tutar.

```cpp
// Hedef API taslağı — henüz bu arşivde uygulanmış değildir.
ClassDB::register_class<CharacterBody3D>("CharacterBody3D")
    .property("velocity", &CharacterBody3D::velocity,
                           &CharacterBody3D::set_velocity)
    .method("move_and_slide", &CharacterBody3D::move_and_slide);
```

Bağlayıcılar aynı metadata'yı tüketir:
- TPScript VM: property/method çağrılarını VM değerlerinden native çağrıya çevirir.
- C#: C ABI/PInvoke üzerinden doğrulanmış native handle ile çağrı yapar.
- Native C++: doğrudan sınıf API'sini kullanır.

C# wrapper, native pointer yerine ObjectId/handle taşır. Her çağrıda handle geçerliliği, nesne ömrü ve thread politikası denetlenir. Managed wrapper native nesneyi sahiplenmez; motorun Object Registry'si ömrü yönetir.
