# Tulpar Engine — Mimari Tasarım

## Kimlik
- Ad: Tulpar Engine
- Sürüm hedefi: 0.1.0
- Çekirdek: Modern C++20
- İlk grafik backend'i: OpenGL 3.3+ (başlangıç prototipi)
- Sonraki backend hedefi: Vulkan
- Editör UI: Dear ImGui docking

## Katmanlar
1. Platform: pencere, giriş, dosya sistemi.
2. Core: loglama, bellek, nesne kimliği, zaman.
3. Scene: Node, Node3D, Transform, sahne serileştirme.
4. Renderer: RHI, mesh, materyal, kamera, ışık.
5. Physics: Jolt adaptörü, rigid body ve character controller.
6. Audio: uzamsal ses.
7. Scripting: TPScript VM, C# host, native modüller.
8. Editor: proje yöneticisi, viewport, hierarchy, inspector, asset browser.

## Bağımlılık kuralı
Core, üst katmanları bilmez. Scene Core'a; Renderer Core ve Scene'e; Editor ise gerekli motor modüllerine bağımlıdır. Döngüsel bağımlılıklara izin verilmez.

## Önemli kapsam notu
Bu arşiv, mimari dokümanları ve ilk editör prototip iskeletini içerir. Tam teşekküllü oyun motoru değildir. TPScript VM, gerçek 3D renderer, fizik, .NET host, proje dosyası serileştirme ve asset pipeline sonraki kilometre taşlarıdır.
