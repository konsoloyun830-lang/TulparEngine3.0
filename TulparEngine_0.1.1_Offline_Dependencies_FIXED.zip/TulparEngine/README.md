# Tulpar Engine 0.1.0

Tulpar Engine is an early native editor/engine skeleton.

## Offline Windows build

This source package bundles Dear ImGui (docking branch) and the GLFW 3.4 Windows
binary package supplied separately. No GitHub download is required during CMake
configuration.

Requirements: Windows, Visual Studio 2022 with the **Desktop development with C++**
workload, CMake 3.25 or newer, and the Windows SDK.

Open **x64 Native Tools Command Prompt for VS 2022**, then run from this folder:

```bat
cmake -S . -B build -G "NMake Makefiles"
cmake --build build --config Release
```

The editor executable is produced under `build\Editor\TulparEditor.exe` (exact
subfolder may vary by generator). The GLFW runtime DLL is copied beside the editor.

## Current limitations

This is an early editor skeleton. The viewport is a UI preview, not a completed
3D renderer. Project creation, scene persistence, TPScript execution, C# runtime,
physics, and audio are not implemented yet.
